1. To install this project, run npm i on your terminal while on elabram-test folder
2. To run the client, type npm run dev on your terminal
3. You may check my github repository to see the git workflow I have used on this project https://github.com/ariobintangn/elabram-test

*NOTES*

- I am trying my best to follow the slicing on Adobe XD
- I have put the color palette accordingly on my tailwind.config.js
- I have tried to optimize the reactive design, but the optimal size to view the app is on Mobile M (375px) and Laptop (1024px)