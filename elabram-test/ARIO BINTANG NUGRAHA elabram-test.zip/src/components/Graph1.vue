<script>
import Chart from 'chart.js/auto'
import { onMounted } from 'vue';

const labels = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
];
const data = {
    labels: labels,
    datasets: [{
        label: 'My First dataset',
        backgroundColor: 'rgb(255, 99, 132)',
        borderColor: 'rgb(255, 99, 132)',
        data: [0, 10, 5, 2, 20, 30, 45],
    }]
};

const config = {
    type: 'line',
    data: data,
    options: {}
};

onMounted(() => {
    const myChart = new Chart(
        document.getElementById('myChart'),
        config
    )
})

</script>


<template>
    <div>
        <h1 id="myChart">GRAPH 1</h1>
    </div>
</template>

