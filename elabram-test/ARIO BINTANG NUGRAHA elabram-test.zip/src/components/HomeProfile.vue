<script>
export default {

}
</script>
<template>
    <div
        class="h-[374px] pb-[16px] my-[16px] bg-white flex flex-col items-center border border-primary-border shadow-sm rounded-md">
        <img src="../assets/home/img-banner-profile.png" class="h-[100px] w-full" />
        <div>
            <img src="../assets/home/Profile Picture@2x.png" class="h-[80px] -translate-y-1/2" />
        </div>
        
        <div class="px-[16px] flex flex-col -translate-y-[35px] w-full">
            <div class="w-full flex flex-col items-center pb-4 border-b border-primary-border">
                <h1 class="font-bold">John Doe</h1>
                <div class="flex flex-row text-sm">
                    <img src="../assets/home/icon - building-1 - 12px.svg" class="mr-[8px]" />
                    <h1>Google Indonesia</h1>
                </div>
            </div>
            <div class="w-full text-sm">
                <div class="my-[16px] flex flex-row justify-between">
                    <h1 class="text-primary-gray-3">Employee ID</h1>
                    <h1 class="text-black">PT - GOO34</h1>
                </div>
                <div class="my-[16px] flex flex-row justify-between">
                    <h1 class="text-primary-gray-3">Position</h1>
                    <h1 class="text-black">Senior Front-End Developer</h1>
                </div>
                <div class="my-[16px] flex flex-row justify-between">
                    <h1 class="text-primary-gray-3">Join Date</h1>
                    <h1 class="text-black">23 Feb 2018</h1>
                </div>
                <div class="my-[16px] flex flex-row justify-between">
                    <h1 class="text-primary-gray-3">Years Of Services</h1>
                    <h1 class="text-black">4 Years 5 Months 2 Days</h1>
                </div>
            </div>
        </div>
    </div>
</template>
